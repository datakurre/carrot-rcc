class BaseLunrException(Exception):
    pass


class QueryParseError(BaseLunrException):
    pass
